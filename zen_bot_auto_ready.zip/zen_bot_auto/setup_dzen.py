from playwright.sync_api import sync_playwright
from config import load_config

def main() -> None:
    cfg = load_config()
    if not cfg.dzen_editor_url:
        raise RuntimeError("Сначала укажите DZEN_EDITOR_URL в .env")

    cfg.dzen_profile_dir.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(cfg.dzen_profile_dir),
            headless=False,
            viewport={"width": 1440, "height": 1000},
        )
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(cfg.dzen_editor_url, wait_until="domcontentloaded", timeout=90000)

        print()
        print("Открылся браузер.")
        print("1. Войдите в Яндекс, если потребуется.")
        print("2. Убедитесь, что открыта студия НУЖНОГО канала Дзена.")
        print("3. Вернитесь в консоль и нажмите Enter.")
        input()
        context.close()
    print("Сессия Дзена сохранена.")

if __name__ == "__main__":
    main()
