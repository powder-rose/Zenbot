from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Не задана обязательная переменная {name}")
    return value

def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name, str(default)).strip().lower()
    return value in {"1", "true", "yes", "on", "да"}

def _int_or_str(value: str) -> int | str:
    value = value.strip()
    return int(value) if value.lstrip("-").isdigit() else value

@dataclass(slots=True)
class Config:
    bot_token: str
    admin_ids: set[int]
    telegram_channel_id: int | str
    yc_folder_id: str
    yc_api_key: str | None
    yc_sa_key_file: str | None
    db_path: Path
    timezone: str
    dzen_enabled: bool
    dzen_editor_url: str | None
    dzen_profile_dir: Path
    dzen_headless: bool
    dzen_new_article_selector: str | None
    dzen_title_selector: str | None
    dzen_body_selector: str | None
    dzen_publish_selector: str | None

def load_config() -> Config:
    admin_ids = {int(x.strip()) for x in _required("ADMIN_IDS").split(",") if x.strip()}
    api_key = os.getenv("YC_API_KEY", "").strip() or None
    sa_key_file = os.getenv("YC_SA_KEY_FILE", "").strip() or None
    if not api_key and not sa_key_file:
        raise RuntimeError("Нужно задать YC_API_KEY или YC_SA_KEY_FILE")

    dzen_enabled = _bool("DZEN_ENABLED", False)
    dzen_editor_url = os.getenv("DZEN_EDITOR_URL", "").strip() or None
    if dzen_enabled and not dzen_editor_url:
        raise RuntimeError("При DZEN_ENABLED=true нужно задать DZEN_EDITOR_URL")

    return Config(
        bot_token=_required("TELEGRAM_BOT_TOKEN"),
        admin_ids=admin_ids,
        telegram_channel_id=_int_or_str(_required("TELEGRAM_CHANNEL_ID")),
        yc_folder_id=_required("YC_FOLDER_ID"),
        yc_api_key=api_key,
        yc_sa_key_file=sa_key_file,
        db_path=Path(os.getenv("DB_PATH", str(BASE_DIR / "data" / "bot.db"))),
        timezone=os.getenv("TIMEZONE", "Europe/Moscow").strip(),
        dzen_enabled=dzen_enabled,
        dzen_editor_url=dzen_editor_url,
        dzen_profile_dir=Path(os.getenv("DZEN_PROFILE_DIR", str(BASE_DIR / "data" / "dzen-profile"))),
        dzen_headless=_bool("DZEN_HEADLESS", True),
        dzen_new_article_selector=os.getenv("DZEN_NEW_ARTICLE_SELECTOR", "").strip() or None,
        dzen_title_selector=os.getenv("DZEN_TITLE_SELECTOR", "").strip() or None,
        dzen_body_selector=os.getenv("DZEN_BODY_SELECTOR", "").strip() or None,
        dzen_publish_selector=os.getenv("DZEN_PUBLISH_SELECTOR", "").strip() or None,
    )
