from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="📋 Мои темы", callback_data="list_topics")
    b.button(text="➕ Добавить темы", callback_data="add_topics")
    b.adjust(1)
    return b.as_markup()


def topic_item_kb(topic_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✍️ Статья", callback_data=f"gen:{topic_id}")
    b.button(text="🏷 Подтема", callback_data=f"subtopic:{topic_id}")
    b.button(text="✏️ Изменить", callback_data=f"edit:{topic_id}")
    b.button(text="🗑 Удалить", callback_data=f"delete:{topic_id}")
    b.adjust(2, 2)
    return b.as_markup()


def back_to_list_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="⬅️ К списку тем", callback_data="list_topics")
    return b.as_markup()


def confirm_delete_kb(topic_id: int) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✅ Да, удалить", callback_data=f"delete_confirm:{topic_id}")
    b.button(text="❌ Отмена", callback_data="list_topics")
    b.adjust(2)
    return b.as_markup()
