from __future__ import annotations

import asyncio
import html
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, CallbackQuery, Message

import db
from article_service import ArticleService
from config import load_config
from image_gen import YandexArtClient
from keyboards import (
    admin_menu,
    schedule_delete,
    schedule_menu,
    topic_actions,
    topics_menu,
    urgent_menu,
)
from scheduler import AutoPublisher
from search import YandexSearchClient
from states import AdminStates
from topics_seed import DEFAULT_TOPICS
from yandex_gpt import YandexGPTClient

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
log = logging.getLogger("zen-bot")

dp = Dispatcher(storage=MemoryStorage())
cfg = load_config()

gpt_client = YandexGPTClient(
    folder_id=cfg.yc_folder_id,
    api_key=cfg.yc_api_key,
    sa_key_file=cfg.yc_sa_key_file,
)
search_client = YandexSearchClient(
    folder_id=cfg.yc_folder_id,
    get_auth_header=gpt_client.auth_header,
)
art_client = YandexArtClient(
    folder_id=cfg.yc_folder_id,
    get_auth_header=gpt_client.auth_header,
)

service: ArticleService | None = None
scheduler: AutoPublisher | None = None

def is_admin(user_id: int | None) -> bool:
    return bool(user_id and user_id in cfg.admin_ids)

async def deny(message_or_call) -> bool:
    user_id = getattr(getattr(message_or_call, "from_user", None), "id", None)
    if is_admin(user_id):
        return False
    if isinstance(message_or_call, CallbackQuery):
        await message_or_call.answer("Нет доступа", show_alert=True)
    else:
        await message_or_call.answer("⛔ Нет доступа.")
    return True

async def show_admin(message: Message) -> None:
    auto = await db.auto_publish_enabled()
    await message.answer(
        "⚙️ <b>Управление автопубликацией</b>\n\n"
        f"Автопубликация: {'🟢 включена' if auto else '🔴 выключена'}\n"
        f"Telegram: <code>{html.escape(str(cfg.telegram_channel_id))}</code>\n"
        f"Дзен: {'🟢 включён' if cfg.dzen_enabled else '⚪ выключен'}",
        parse_mode="HTML",
        reply_markup=admin_menu(),
    )

@dp.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    if is_admin(message.from_user.id):
        await show_admin(message)
    else:
        await message.answer("🤖 Бот работает в автоматическом режиме публикации статей.")

@dp.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    if await deny(message):
        return
    await state.clear()
    await show_admin(message)

@dp.callback_query(F.data == "admin:home")
async def cb_home(call: CallbackQuery, state: FSMContext):
    if await deny(call):
        return
    await state.clear()
    await call.answer()
    await show_admin(call.message)

# ---------------- ТЕМЫ

@dp.callback_query(F.data == "admin:topics")
async def cb_topics(call: CallbackQuery):
    if await deny(call):
        return
    await call.answer()
    await call.message.answer(
        "📝 <b>Темы</b>\n\n"
        "Автоматически берётся только тема, которая ещё ни разу не использовалась.",
        parse_mode="HTML",
        reply_markup=topics_menu(),
    )

@dp.callback_query(F.data == "topics:add")
async def cb_topics_add(call: CallbackQuery, state: FSMContext):
    if await deny(call):
        return
    await state.set_state(AdminStates.waiting_topics)
    await call.answer()
    await call.message.answer(
        "Пришлите темы одним сообщением.\nКаждая новая строка = отдельная тема."
    )

@dp.message(AdminStates.waiting_topics)
async def process_topics_add(message: Message, state: FSMContext):
    if await deny(message):
        return
    lines = (message.text or "").splitlines()
    count = await db.add_topics(lines)
    await state.clear()
    await message.answer(f"✅ Добавлено новых тем: {count}", reply_markup=topics_menu())

async def send_topics_list(message: Message, mode: str) -> None:
    rows = await db.list_topics(mode=mode, limit=50)
    title = "Неиспользованные темы" if mode == "unused" else "Использованные темы"
    if not rows:
        await message.answer(f"📋 {title}: список пуст.")
        return

    await message.answer(f"📋 <b>{title}</b>: {len(rows)}", parse_mode="HTML")
    for row in rows:
        used = f"\nОпубликована: {row['used_at']}" if row["used_at"] else ""
        await message.answer(
            f"#{row['id']} — {html.escape(row['title'])}{used}",
            parse_mode="HTML",
            reply_markup=topic_actions(int(row["id"])),
        )

@dp.callback_query(F.data.startswith("topics:list:"))
async def cb_topics_list(call: CallbackQuery):
    if await deny(call):
        return
    mode = call.data.rsplit(":", 1)[1]
    await call.answer()
    await send_topics_list(call.message, mode)

@dp.callback_query(F.data.startswith("topic:edit:"))
async def cb_topic_edit(call: CallbackQuery, state: FSMContext):
    if await deny(call):
        return
    topic_id = int(call.data.rsplit(":", 1)[1])
    row = await db.get_topic(topic_id)
    if not row:
        await call.answer("Тема не найдена", show_alert=True)
        return
    await state.update_data(topic_id=topic_id)
    await state.set_state(AdminStates.waiting_edit_topic)
    await call.answer()
    await call.message.answer(
        f"Текущее название:\n{row['title']}\n\nПришлите новое название:"
    )

@dp.message(AdminStates.waiting_edit_topic)
async def process_topic_edit(message: Message, state: FSMContext):
    if await deny(message):
        return
    data = await state.get_data()
    ok = await db.update_topic(int(data["topic_id"]), message.text or "")
    await state.clear()
    if ok:
        await message.answer("✅ Тема изменена.", reply_markup=topics_menu())
    else:
        await message.answer(
            "❌ Не удалось изменить тему. Возможно, такое название уже существует.",
            reply_markup=topics_menu(),
        )

@dp.callback_query(F.data.startswith("topic:delete:"))
async def cb_topic_delete(call: CallbackQuery):
    if await deny(call):
        return
    topic_id = int(call.data.rsplit(":", 1)[1])
    ok = await db.deactivate_topic(topic_id)
    await call.answer("Удалено" if ok else "Тема не найдена")
    if ok:
        await call.message.edit_text("🗑 Тема удалена из активного списка.")

# ---------------- РАСПИСАНИЕ

async def send_schedule(message: Message) -> None:
    rows = await db.list_schedule()
    auto = await db.auto_publish_enabled()
    await message.answer(
        "⏰ <b>Расписание</b>\n\n"
        f"Статус: {'🟢 включено' if auto else '🔴 выключено'}\n"
        f"Часовой пояс: <code>{html.escape(cfg.timezone)}</code>",
        parse_mode="HTML",
        reply_markup=schedule_menu(),
    )
    if not rows:
        await message.answer("Время публикаций пока не задано.")
        return
    for row in rows:
        await message.answer(
            f"🕒 {row['publish_time']}",
            reply_markup=schedule_delete(int(row["id"])),
        )

@dp.callback_query(F.data == "admin:schedule")
async def cb_schedule(call: CallbackQuery):
    if await deny(call):
        return
    await call.answer()
    await send_schedule(call.message)

@dp.callback_query(F.data == "schedule:add")
async def cb_schedule_add(call: CallbackQuery, state: FSMContext):
    if await deny(call):
        return
    await state.set_state(AdminStates.waiting_schedule_time)
    await call.answer()
    await call.message.answer("Введите время публикации в формате ЧЧ:ММ.\nНапример: 09:00")

@dp.message(AdminStates.waiting_schedule_time)
async def process_schedule_add(message: Message, state: FSMContext):
    if await deny(message):
        return
    value = (message.text or "").strip()
    ok = await db.add_schedule_time(value)
    if not ok:
        await message.answer("❌ Неверный формат или такое время уже есть.\nВведите, например: 13:30")
        return
    await state.clear()
    await message.answer("✅ Время добавлено.")
    await send_schedule(message)

@dp.callback_query(F.data.startswith("schedule:delete:"))
async def cb_schedule_delete(call: CallbackQuery):
    if await deny(call):
        return
    schedule_id = int(call.data.rsplit(":", 1)[1])
    await db.delete_schedule_time(schedule_id)
    await call.answer("Удалено")
    await call.message.edit_text("🗑 Время удалено.")

@dp.callback_query(F.data == "schedule:toggle")
async def cb_schedule_toggle(call: CallbackQuery):
    if await deny(call):
        return
    current = await db.auto_publish_enabled()
    await db.set_auto_publish_enabled(not current)
    await call.answer("Настройка изменена")
    await send_schedule(call.message)

# ---------------- СРОЧНАЯ СТАТЬЯ

@dp.callback_query(F.data == "admin:urgent")
async def cb_urgent(call: CallbackQuery):
    if await deny(call):
        return
    await call.answer()
    await call.message.answer(
        "⚡ <b>Срочная статья</b>\nПубликация запускается сразу и не ждёт расписания.",
        parse_mode="HTML",
        reply_markup=urgent_menu(),
    )

def result_text(result: dict) -> str:
    status = result.get("status")
    if status == "no_topics":
        return "⚠️ Неиспользованные темы закончились."
    if status != "ok":
        return "❌ Статья не создана.\nОшибка: " + str(result.get("error", "неизвестная ошибка"))
    return (
        "✅ Статья обработана.\n\n"
        f"Тема: {result.get('topic')}\n"
        f"Заголовок: {result.get('article_title')}\n"
        f"Telegram: {result.get('telegram')}\n"
        f"Дзен: {result.get('dzen')}"
        + (f"\nURL Дзена: {result.get('dzen_url')}" if result.get("dzen_url") else "")
    )

@dp.callback_query(F.data == "urgent:random")
async def cb_urgent_random(call: CallbackQuery):
    if await deny(call):
        return
    if service is None:
        await call.answer("Сервис ещё не запущен", show_alert=True)
        return
    await call.answer()
    status = await call.message.answer(
        "⚡ Выбираю случайную неиспользованную тему и начинаю публикацию…"
    )
    result = await service.publish_random_topic(trigger="urgent_random")
    await status.edit_text(result_text(result))

@dp.callback_query(F.data == "urgent:manual")
async def cb_urgent_manual(call: CallbackQuery, state: FSMContext):
    if await deny(call):
        return
    await state.set_state(AdminStates.waiting_urgent_topic)
    await call.answer()
    await call.message.answer("Введите тему срочной статьи:")

@dp.message(AdminStates.waiting_urgent_topic)
async def process_urgent_manual(message: Message, state: FSMContext):
    if await deny(message):
        return
    if service is None:
        await message.answer("Сервис ещё не запущен.")
        return
    topic = " ".join((message.text or "").split())
    await state.clear()
    status = await message.answer(f"⚡ Создаю внеплановую статью по теме:\n{topic}")
    result = await service.publish_manual_topic(topic)
    await status.edit_text(result_text(result))

# ---------------- СТАТИСТИКА / ДЗЕН

@dp.callback_query(F.data == "admin:stats")
async def cb_stats(call: CallbackQuery):
    if await deny(call):
        return
    await call.answer()
    stats = await db.stats()
    await call.message.answer(
        "📊 <b>Статистика</b>\n\n"
        f"Всего статей: {stats['total']}\n"
        f"Тем осталось: {stats['unused']}\n"
        f"Тем использовано: {stats['used']}\n"
        f"Telegram опубликовано: {stats['telegram_published']}\n"
        f"Дзен опубликовано: {stats['dzen_published']}\n"
        f"Ошибок Дзена: {stats['dzen_errors']}\n"
        f"Последняя статья: {html.escape(stats['last_title'] or '—')}",
        parse_mode="HTML",
        reply_markup=admin_menu(),
    )

@dp.callback_query(F.data == "admin:retry_dzen")
async def cb_retry_dzen(call: CallbackQuery):
    if await deny(call):
        return
    if service is None:
        await call.answer("Сервис ещё не запущен", show_alert=True)
        return
    await call.answer()
    msg = await call.message.answer("🔁 Повторяю публикации, которые не ушли в Дзен…")
    result = await service.retry_dzen_errors()
    await msg.edit_text(
        "Готово.\n"
        f"Успешно: {result['success']}\n"
        f"С ошибкой: {result['failed']}\n"
        f"Пропущено: {result['skipped']}"
    )

async def main():
    global service, scheduler

    await db.init_db(cfg.db_path)
    seeded = await db.seed_topics(DEFAULT_TOPICS)
    log.info("Добавлено стартовых тем: %s", seeded)

    if not await db.list_schedule():
        await db.add_schedule_time("10:00")

    bot = Bot(token=cfg.bot_token)

    service = ArticleService(
        bot=bot,
        cfg=cfg,
        gpt_client=gpt_client,
        search_client=search_client,
        art_client=art_client,
    )
    scheduler = AutoPublisher(service, cfg)

    await bot.set_my_commands([
        BotCommand(command="start", description="Открыть бота"),
        BotCommand(command="admin", description="Панель администратора"),
    ])

    scheduler_task = asyncio.create_task(scheduler.run())
    try:
        await dp.start_polling(bot)
    finally:
        scheduler.stop()
        scheduler_task.cancel()
        try:
            await scheduler_task
        except asyncio.CancelledError:
            pass
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
