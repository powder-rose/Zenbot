"""
Клиент YandexGPT (Yandex Cloud Foundation Models).

Поддерживает два варианта авторизации сервисного аккаунта:
  1. Статический API-ключ (YC_API_KEY) — проще всего для старта.
  2. JSON-ключ сервисного аккаунта (YC_SA_KEY_FILE) -> подпись JWT -> IAM-токен.
     Нужные роли на сервисном аккаунте: ai.languageModels.user, search-api.executor.

Метод generate_article_from_sources() не даёт модели "придумывать" статью
из общих знаний — в промпт передаются только реально найденные через
YandexSearchClient источники, и модель обязана опираться только на них.
"""

import json
import time

import httpx
import jwt

IAM_TOKEN_URL = "https://iam.api.cloud.yandex.net/iam/v1/tokens"
COMPLETION_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"

SYSTEM_PROMPT = (
    "Ты — профессиональный журналист-редактор. Тебе передан список источников "
    "(заголовок, ссылка, выдержка), найденных поисковой системой по теме статьи. "
    "Правила:\n"
    "1. Используй факты ТОЛЬКО из переданных источников. Ничего не выдумывай.\n"
    "2. Если источников недостаточно для какого-то утверждения — не делай это "
    "утверждение, а не придумывай данные.\n"
    "3. В конце статьи добавь раздел «Источники» со списком использованных ссылок.\n"
    "4. Пиши структурированно: заголовок, вступление, 3-5 разделов с подзаголовками, "
    "заключение."
)


class YandexGPTClient:
    def __init__(
        self,
        folder_id: str,
        api_key: str | None = None,
        sa_key_file: str | None = None,
    ):
        self.folder_id = folder_id
        self.api_key = api_key
        self.sa_key_file = sa_key_file
        self._iam_token: str | None = None
        self._iam_expires_at: float = 0

    # ---------- авторизация ----------

    def _load_sa_key(self) -> dict:
        with open(self.sa_key_file, "r", encoding="utf-8") as f:
            return json.load(f)

    async def _get_iam_token(self) -> str:
        if self._iam_token and time.time() < self._iam_expires_at - 60:
            return self._iam_token

        key = self._load_sa_key()
        now = int(time.time())
        payload = {
            "aud": IAM_TOKEN_URL,
            "iss": key["service_account_id"],
            "iat": now,
            "exp": now + 3600,
        }
        encoded_jwt = jwt.encode(
            payload,
            key["private_key"],
            algorithm="PS256",
            headers={"kid": key["id"]},
        )
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(IAM_TOKEN_URL, json={"jwt": encoded_jwt})
            resp.raise_for_status()
            data = resp.json()

        self._iam_token = data["iamToken"]
        self._iam_expires_at = now + 3600
        return self._iam_token

    async def auth_header(self) -> dict:
        """Единая точка авторизации — переиспользуется YandexSearchClient."""
        if self.api_key:
            return {"Authorization": f"Api-Key {self.api_key}"}
        token = await self._get_iam_token()
        return {"Authorization": f"Bearer {token}"}

    # ---------- генерация текста ----------

    async def _complete(self, system_text: str, user_text: str, max_tokens: int = 2500) -> str:
        headers = await self.auth_header()
        headers["x-folder-id"] = self.folder_id
        body = {
            "modelUri": f"gpt://{self.folder_id}/yandexgpt/latest",
            "completionOptions": {
                "stream": False,
                "temperature": 0.3,
                "maxTokens": max_tokens,
            },
            "messages": [
                {"role": "system", "text": system_text},
                {"role": "user", "text": user_text},
            ],
        }
        async with httpx.AsyncClient(timeout=90) as client:
            resp = await client.post(COMPLETION_URL, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()
        return data["result"]["alternatives"][0]["message"]["text"]

    async def generate_article_from_sources(
        self,
        topic: str,
        sources: list,  # list[SearchResult]
        subtopic: str | None = None,
    ) -> str:
        if not sources:
            sources_block = "Источники не найдены."
        else:
            parts = []
            for i, s in enumerate(sources, start=1):
                parts.append(f"[{i}] {s.title}\nСсылка: {s.url}\nВыдержка: {s.snippet}")
            sources_block = "\n\n".join(parts)

        user_text = f'Тема статьи: "{topic}"\n'
        if subtopic:
            user_text += f'Подтема (сделай на неё акцент): "{subtopic}"\n'
        user_text += f"\nНайденные источники:\n\n{sources_block}\n\n"
        user_text += "Напиши статью объёмом 600-900 слов, опираясь только на эти источники."

        return await self._complete(SYSTEM_PROMPT, user_text)
