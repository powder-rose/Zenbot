import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery

import db
from config import load_config
from keyboards import main_menu, topic_item_kb, back_to_list_kb, confirm_delete_kb
from search import YandexSearchClient
from states import TopicStates
from yandex_gpt import YandexGPTClient

logging.basicConfig(level=logging.INFO)
router_dp = Dispatcher(storage=MemoryStorage())

cfg = load_config()
gpt_client = YandexGPTClient(
    folder_id=cfg.yc_folder_id,
    api_key=cfg.yc_api_key,
    sa_key_file=cfg.yc_sa_key_file,
)
search_client = YandexSearchClient(
    folder_id=cfg.yc_folder_id,
    get_auth_header=gpt_client.auth_header,
)


# ---------------------------------------------------------------- /start

@router_dp.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "👋 Привет! Я помогу писать статьи по темам.\n\n"
        "1️⃣ Сначала добавь темы — по одной в строке.\n"
        "2️⃣ Для каждой темы можно задать подтему, отредактировать или удалить её.\n"
        "3️⃣ Затем выбери тему и нажми «✍️ Статья» — я найду источники и напишу текст.",
        reply_markup=main_menu(),
    )


# ---------------------------------------------------------------- список тем

@router_dp.callback_query(F.data == "list_topics")
async def cb_list_topics(call: CallbackQuery, state: FSMContext):
    await state.clear()
    topics = await db.get_topics(call.from_user.id)
    if not topics:
        await call.message.edit_text(
            "Тем пока нет. Нажми «➕ Добавить темы», чтобы начать.",
            reply_markup=main_menu(),
        )
        await call.answer()
        return

    await call.message.edit_text("📋 Твои темы:", reply_markup=main_menu())
    for t in topics:
        text = f"• {t['title']}"
        if t["subtopic"]:
            text += f"\n   подтема: {t['subtopic']}"
        await call.message.answer(text, reply_markup=topic_item_kb(t["id"]))
    await call.answer()


# ---------------------------------------------------------------- добавление тем

@router_dp.callback_query(F.data == "add_topics")
async def cb_add_topics(call: CallbackQuery, state: FSMContext):
    await state.set_state(TopicStates.waiting_for_topics)
    await call.message.answer(
        "Пришли одним сообщением список тем — каждая тема с новой строки.\n\n"
        "Например:\n<code>Искусственный интеллект в медицине\n"
        "Изменение климата\nКриптовалюты и регулирование</code>",
        parse_mode="HTML",
    )
    await call.answer()


@router_dp.message(TopicStates.waiting_for_topics)
async def process_add_topics(message: Message, state: FSMContext):
    lines = message.text.splitlines()
    await db.add_topics(message.from_user.id, lines)
    await state.clear()
    count = len([line for line in lines if line.strip()])
    await message.answer(f"Добавлено тем: {count} ✅", reply_markup=main_menu())


# ---------------------------------------------------------------- удаление

@router_dp.callback_query(F.data.startswith("delete:"))
async def cb_delete_ask(call: CallbackQuery):
    topic_id = int(call.data.split(":")[1])
    topic = await db.get_topic(topic_id)
    if not topic:
        await call.answer("Тема не найдена", show_alert=True)
        return
    await call.message.edit_text(
        f"Удалить тему «{topic['title']}»?", reply_markup=confirm_delete_kb(topic_id)
    )
    await call.answer()


@router_dp.callback_query(F.data.startswith("delete_confirm:"))
async def cb_delete_confirm(call: CallbackQuery):
    topic_id = int(call.data.split(":")[1])
    await db.delete_topic(topic_id)
    await call.message.edit_text("Тема удалена 🗑", reply_markup=back_to_list_kb())
    await call.answer()


# ---------------------------------------------------------------- редактирование названия

@router_dp.callback_query(F.data.startswith("edit:"))
async def cb_edit_ask(call: CallbackQuery, state: FSMContext):
    topic_id = int(call.data.split(":")[1])
    await state.update_data(topic_id=topic_id)
    await state.set_state(TopicStates.waiting_for_new_title)
    await call.message.answer("Пришли новое название темы:")
    await call.answer()


@router_dp.message(TopicStates.waiting_for_new_title)
async def process_edit_title(message: Message, state: FSMContext):
    data = await state.get_data()
    await db.update_topic_title(data["topic_id"], message.text.strip())
    await state.clear()
    await message.answer("Название обновлено ✅", reply_markup=main_menu())


# ---------------------------------------------------------------- подтема

@router_dp.callback_query(F.data.startswith("subtopic:"))
async def cb_subtopic_ask(call: CallbackQuery, state: FSMContext):
    topic_id = int(call.data.split(":")[1])
    await state.update_data(topic_id=topic_id)
    await state.set_state(TopicStates.waiting_for_subtopic)
    await call.message.answer(
        "Пришли подтему (или «-», чтобы убрать текущую подтему):"
    )
    await call.answer()


@router_dp.message(TopicStates.waiting_for_subtopic)
async def process_subtopic(message: Message, state: FSMContext):
    data = await state.get_data()
    value = message.text.strip()
    await db.set_subtopic(data["topic_id"], None if value == "-" else value)
    await state.clear()
    await message.answer("Подтема сохранена ✅", reply_markup=main_menu())


# ---------------------------------------------------------------- генерация статьи

@router_dp.callback_query(F.data.startswith("gen:"))
async def cb_generate(call: CallbackQuery):
    topic_id = int(call.data.split(":")[1])
    topic = await db.get_topic(topic_id)
    if not topic:
        await call.answer("Тема не найдена", show_alert=True)
        return

    await call.answer("Начинаю: ищу источники и пишу статью…")
    status_msg = await call.message.answer("🔎 Ищу достоверные источники…")

    query = topic["title"] if not topic["subtopic"] else f"{topic['title']} {topic['subtopic']}"
    try:
        sources = await search_client.search(query, max_results=5)
    except Exception as e:
        logging.exception("Ошибка поиска")
        await status_msg.edit_text(f"Не удалось выполнить поиск источников: {e}")
        return

    await status_msg.edit_text(
        f"🔎 Нашёл источников: {len(sources)}\n✍️ Пишу статью…"
    )

    try:
        article = await gpt_client.generate_article_from_sources(
            topic=topic["title"], sources=sources, subtopic=topic["subtopic"]
        )
    except Exception as e:
        logging.exception("Ошибка генерации")
        await status_msg.edit_text(f"Не удалось сгенерировать статью: {e}")
        return

    await status_msg.delete()
    # Telegram режет сообщения на 4096 символов — бьём статью на части
    for i in range(0, len(article), 4000):
        await call.message.answer(article[i : i + 4000])


# ---------------------------------------------------------------- запуск

async def main():
    await db.init_db(cfg.db_path)
    bot = Bot(token=cfg.bot_token)
    await router_dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
