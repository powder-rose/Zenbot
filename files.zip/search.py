"""
Клиент Yandex Search API (v2) — используется, чтобы модель писала статьи
не "из головы", а по реальным найденным источникам.

Документация: https://yandex.cloud/en/docs/search-api/
Сервисному аккаунту нужна роль search-api.executor (плюс ai.languageModels.user для YandexGPT).

Формат ответа v2: {"rawData": "<base64>"}, внутри — XML с найденными документами.
"""

import base64
import xml.etree.ElementTree as ET
from dataclasses import dataclass

import httpx

SEARCH_URL = "https://searchapi.api.cloud.yandex.net/v2/web/search"


@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str


class YandexSearchClient:
    def __init__(self, folder_id: str, get_auth_header):
        """
        get_auth_header — асинхронная функция без аргументов, возвращающая dict
        с заголовком Authorization (см. YandexGPTClient._auth_header).
        Так один и тот же механизм авторизации (API-ключ или IAM-токен от
        сервисного аккаунта) используется и для поиска, и для генерации текста.
        """
        self.folder_id = folder_id
        self.get_auth_header = get_auth_header

    async def search(self, query: str, max_results: int = 5) -> list[SearchResult]:
        body = {
            "query": {
                "searchType": "SEARCH_TYPE_RU",
                "queryText": query,
                "familyMode": "FAMILY_MODE_MODERATE",
            },
            "folderId": self.folder_id,
            "responseFormat": "FORMAT_XML",
            "maxPassages": "3",
        }
        headers = await self.get_auth_header()

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(SEARCH_URL, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        raw_b64 = data.get("rawData")
        if not raw_b64:
            return []

        xml_bytes = base64.b64decode(raw_b64)
        return self._parse_xml(xml_bytes, max_results)

    @staticmethod
    def _parse_xml(xml_bytes: bytes, max_results: int) -> list[SearchResult]:
        results: list[SearchResult] = []
        try:
            root = ET.fromstring(xml_bytes)
        except ET.ParseError:
            return results

        # Структура ответа Yandex Search XML: response/results/grouping/group/doc
        for doc in root.iter("doc"):
            if len(results) >= max_results:
                break
            url_el = doc.find("url")
            title_el = doc.find("title")
            if url_el is None or not url_el.text:
                continue

            passages = [
                "".join(p.itertext()).strip()
                for p in doc.iter("passage")
                if "".join(p.itertext()).strip()
            ]
            title = "".join(title_el.itertext()).strip() if title_el is not None else url_el.text
            snippet = " ".join(passages)[:500]

            results.append(SearchResult(title=title, url=url_el.text, snippet=snippet))

        return results
