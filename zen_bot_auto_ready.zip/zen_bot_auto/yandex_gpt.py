from __future__ import annotations
import asyncio, json, re, ssl, time
from pathlib import Path
from typing import Any
import httpx, jwt, truststore

IAM_TOKEN_URL = "https://iam.api.cloud.yandex.net/iam/v1/tokens"
COMPLETION_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"

def _ssl_context():
    ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.maximum_version = ssl.TLSVersion.TLSv1_2
    try:
        ctx.options |= ssl.OP_LEGACY_SERVER_CONNECT
    except AttributeError:
        pass
    return ctx

ARTICLE_SYSTEM_PROMPT = """
Ты пишешь экспертную журнальную статью для руководителей организаций, ИП,
специалистов по охране труда, пожарной безопасности, ГО и ЧС и ответственных лиц.

Автор статьи — Николай Бойков, генеральный директор ООО «Спецконс».
Компания занимается сопровождением организаций по направлениям безопасности.

Стиль: спокойный, профессиональный, человеческий, логичный, без канцелярита,
запугивания, рекламных лозунгов и навязчивых продаж. Не повторяй одну мысль
разными словами. Не используй конструкции «не просто ..., а ...».

Используй только факты, которые можно обосновать предоставленными источниками.
Если в источниках нет точного номера нормативного акта, даты или требования —
не выдумывай их. Ссылки, URL, названия сайтов, сноски и номера источников
в готовой статье не публикуй.

Объём основного текста: ориентир 3500–4000 символов без пробелов.
В статье должен быть только один заголовок — тот, который вернётся отдельно
после метки «ЗАГОЛОВОК:». Внутри текста не создавай подзаголовки.

Начало — 1–2 содержательных абзаца с узнаваемой рабочей ситуацией.
Основная часть — последовательное объяснение темы с практической логикой.
В середине естественно представь автора:
«Меня зовут Николай Бойков, я генеральный директор ООО „Спецконс“.»

В конце сделай 1–2 спокойных завершающих абзаца.
После них добавь 3–5 коротких итоговых пунктов с символом •.
Перед пунктами не должно быть никакого заголовка.
Никогда не пиши слова «РЕЗЮМЕ», «ИТОГИ», «ВЫВОДЫ», «ГЛАВНОЕ»
как название блока.

После пунктов отдельным абзацем напиши точно:
«Чтобы вы могли избежать ошибок и понимать, как действовать в реальных ситуациях,
я собрал практические разборы отдельно — ссылка есть в описании канала.»

Последняя строка — короткий вопрос читателю по теме статьи.

Формат ответа:
ЗАГОЛОВОК: <один заголовок>

ТЕКСТ:
<готовый текст>

Не используй Markdown: #, ##, ###, **, __, ``` и т. п.
Допускаются только редкие HTML-теги <b>...</b> и <i>...</i>.
""".strip()

class YandexGPTClient:
    def __init__(self, folder_id: str, api_key: str | None = None, sa_key_file: str | None = None):
        self.folder_id = folder_id
        self.api_key = api_key
        self.sa_key_file = sa_key_file
        self._iam_token = None
        self._iam_expires_at = 0.0
        self._ssl = _ssl_context()

    def _get_iam_token_sync(self) -> str:
        if self._iam_token and time.time() < self._iam_expires_at - 60:
            return self._iam_token
        if not self.sa_key_file:
            raise RuntimeError("Не задан YC_SA_KEY_FILE")
        data = json.loads(Path(self.sa_key_file).read_text(encoding="utf-8"))
        now = int(time.time())
        encoded = jwt.encode(
            {"aud": IAM_TOKEN_URL, "iss": data["service_account_id"], "iat": now, "exp": now + 360},
            data["private_key"],
            algorithm="PS256",
            headers={"kid": data["id"]},
        )
        with httpx.Client(verify=self._ssl, trust_env=False, http1=True, http2=False, timeout=30) as client:
            response = client.post(IAM_TOKEN_URL, json={"jwt": encoded})
        if response.status_code >= 400:
            raise RuntimeError(f"IAM HTTP {response.status_code}: {response.text}")
        result = response.json()
        self._iam_token = result["iamToken"]
        self._iam_expires_at = time.time() + 3500
        return self._iam_token

    async def auth_header(self) -> str:
        if self.api_key:
            return f"Api-Key {self.api_key}"
        token = await asyncio.to_thread(self._get_iam_token_sync)
        return f"Bearer {token}"

    def _complete_sync(self, auth: str, system_prompt: str, user_prompt: str) -> str:
        body = {
            "modelUri": f"gpt://{self.folder_id}/yandexgpt/latest",
            "completionOptions": {"stream": False, "temperature": 0.35, "maxTokens": "3200"},
            "messages": [
                {"role": "system", "text": system_prompt},
                {"role": "user", "text": user_prompt},
            ],
        }
        with httpx.Client(verify=self._ssl, trust_env=False, http1=True, http2=False, timeout=180) as client:
            response = client.post(
                COMPLETION_URL,
                headers={"Authorization": auth, "Content-Type": "application/json"},
                json=body,
            )
        if response.status_code >= 400:
            raise RuntimeError(f"YandexGPT HTTP {response.status_code}: {response.text}")
        data = response.json()
        alternatives = data.get("result", {}).get("alternatives") or data.get("alternatives")
        if not alternatives:
            raise RuntimeError(f"YandexGPT вернул неожиданный ответ: {data}")
        text = alternatives[0].get("message", {}).get("text", "").strip()
        if not text:
            raise RuntimeError("YandexGPT вернул пустой текст")
        return text

    @staticmethod
    def _cleanup(text: str) -> str:
        text = text.replace("\r\n", "\n")
        text = re.sub(r"(?m)^\s*#{1,6}\s*", "", text)
        text = text.replace("**", "").replace("__", "").replace("```", "")
        text = re.sub(
            r"(?im)^\s*(?:<b>\s*)?(?:РЕЗЮМЕ|ИТОГИ|ВЫВОДЫ|ГЛАВНОЕ)(?:\s*</b>)?\s*:?\s*$",
            "",
            text,
        )
        return re.sub(r"\n{3,}", "\n\n", text).strip()

    @classmethod
    def _parse(cls, text: str) -> tuple[str, str]:
        text = cls._cleanup(text)
        m_body = re.search(r"(?is)\bТЕКСТ:\s*(.+)$", text)
        if not m_body:
            lines = [x.strip() for x in text.splitlines() if x.strip()]
            if not lines:
                raise RuntimeError("Не удалось разобрать ответ YandexGPT")
            return lines[0], "\n".join(lines[1:]).strip()
        before = text[:m_body.start()]
        title = re.sub(r"(?is)^\s*ЗАГОЛОВОК:\s*", "", before).strip()
        body = cls._cleanup(m_body.group(1))
        first = re.sub(r"<[^>]+>", "", body.split("\n", 1)[0]).strip()
        if first.casefold() == title.casefold():
            body = body.split("\n", 1)[1].lstrip() if "\n" in body else ""
        return re.sub(r"<[^>]+>", "", title).strip(), body

    async def generate_article_from_sources(
        self, topic: str, sources: list[dict[str, Any]],
        subtopic: str | None = None, max_chars: int = 4500
    ) -> tuple[str, str]:
        blocks = []
        for i, src in enumerate(sources[:8], 1):
            blocks.append(
                f"ИСТОЧНИК {i}\nНазвание: {src.get('title','')}\n"
                f"URL: {src.get('url','')}\nФрагмент: {src.get('snippet','')}"
            )
        user_prompt = (
            f"ТЕМА СТАТЬИ: {topic}\n"
            + (f"ПОДТЕМА/АКЦЕНТ: {subtopic}\n" if subtopic else "")
            + "\nИСТОЧНИКИ ДЛЯ ПРОВЕРКИ ФАКТОВ:\n\n"
            + "\n\n".join(blocks)
            + f"\n\nОриентир верхней границы текста: {max_chars} символов."
        )
        auth = await self.auth_header()
        raw = await asyncio.to_thread(self._complete_sync, auth, ARTICLE_SYSTEM_PROMPT, user_prompt)
        return self._parse(raw)
