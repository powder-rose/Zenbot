from __future__ import annotations

import asyncio
import html
import logging
import re
from typing import Any

from aiogram import Bot
from aiogram.types import (
    BufferedInputFile,
    InputMediaPhoto,
    InputRichMessage,
    InputRichMessageMedia,
)

import db
from config import Config
from dzen_publisher import DzenPublisher
from image_gen import YandexArtClient
from search import YandexSearchClient
from yandex_gpt import YandexGPTClient

log = logging.getLogger(__name__)

def format_article_html(text: str) -> str:
    escaped = html.escape(text)
    for escaped_tag, real_tag in {
        "&lt;b&gt;": "<b>", "&lt;/b&gt;": "</b>",
        "&lt;i&gt;": "<i>", "&lt;/i&gt;": "</i>",
    }.items():
        escaped = escaped.replace(escaped_tag, real_tag)
    return escaped

def plain_text(text: str) -> str:
    text = re.sub(r"</?(?:b|i)>", "", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return html.unescape(text).strip()

def build_image_prompt(topic: str) -> str:
    style = (
        "Минималистичная editorial-иллюстрация в корпоративном стиле. "
        "Покажи человека или предмет, напрямую связанный с темой статьи. "
        "Главный образ точно передаёт смысл. Нереалистичный, слегка абстрактный стиль: "
        "чёткие силуэты, простые формы, минимум деталей, допустима геометризация. "
        "Персонаж: маленькая голова, крупные руки и тело. "
        "Образ почти на весь кадр, немного воздуха. "
        "Приглушённые цвета, один акцент — синий или оранжевый. Без текста и логотипов."
    )
    prefix = "Тема: "
    available = max(35, 480 - len(prefix) - len(style) - 2)
    short_topic = " ".join(topic.split())
    if len(short_topic) > available:
        short_topic = short_topic[:available].rsplit(" ", 1)[0].rstrip()
    result = f"{prefix}{short_topic}. {style}"
    if len(result) > 480:
        result = result[:480].rsplit(" ", 1)[0].rstrip()
    return result

async def send_rich_article(
    bot: Bot,
    chat_id: int | str,
    title: str,
    body: str,
    image_bytes: bytes,
) -> str | None:
    paragraphs = []
    for paragraph in body.strip().splitlines():
        paragraph = paragraph.strip()
        if paragraph:
            paragraphs.append(f"<p>{format_article_html(paragraph)}</p>")
    article_html = "".join(paragraphs)

    image_file = BufferedInputFile(image_bytes, filename="article.jpg")
    rich_message = InputRichMessage(
        html=(
            '<img src="tg://photo?id=article_cover"/>'
            f"<h1>{html.escape(title.strip())}</h1>"
            f"{article_html}"
        ),
        media=[
            InputRichMessageMedia(
                id="article_cover",
                media=InputMediaPhoto(media=image_file),
            )
        ],
    )
    result = await bot.send_rich_message(
        chat_id=chat_id,
        rich_message=rich_message,
    )
    return str(getattr(result, "message_id", "") or "") or None

async def send_text_chunks(
    bot: Bot,
    chat_id: int | str,
    title: str,
    body: str,
) -> str | None:
    full = f"<b>{html.escape(title)}</b>\n\n{format_article_html(body)}".strip()
    first_message_id = None

    while full:
        if len(full) <= 3900:
            chunk, full = full, ""
        else:
            cut = full[:3900]
            split_at = max(cut.rfind("\n\n"), cut.rfind("\n"), cut.rfind(" "))
            if split_at < 2600:
                split_at = 3900
            chunk = full[:split_at].rstrip()
            full = full[split_at:].lstrip()

        msg = await bot.send_message(chat_id=chat_id, text=chunk, parse_mode="HTML")
        if first_message_id is None:
            first_message_id = str(msg.message_id)

    return first_message_id

class ArticleService:
    def __init__(
        self, *, bot: Bot, cfg: Config,
        gpt_client: YandexGPTClient,
        search_client: YandexSearchClient,
        art_client: YandexArtClient,
    ):
        self.bot = bot
        self.cfg = cfg
        self.gpt = gpt_client
        self.search = search_client
        self.art = art_client
        self.lock = asyncio.Lock()

        self.image_dir = cfg.db_path.parent / "images"
        self.image_dir.mkdir(parents=True, exist_ok=True)

        self.dzen = None
        if cfg.dzen_enabled and cfg.dzen_editor_url:
            self.dzen = DzenPublisher(
                editor_url=cfg.dzen_editor_url,
                profile_dir=cfg.dzen_profile_dir,
                headless=cfg.dzen_headless,
                new_article_selector=cfg.dzen_new_article_selector,
                title_selector=cfg.dzen_title_selector,
                body_selector=cfg.dzen_body_selector,
                publish_selector=cfg.dzen_publish_selector,
            )

    async def _generate(self, topic_title: str):
        sources = await self.search.search(topic_title, max_results=5)
        title, body = await self.gpt.generate_article_from_sources(
            topic=topic_title,
            sources=sources,
            max_chars=4500,
        )

        image_bytes = None
        try:
            prompt = build_image_prompt(topic_title)
            log.info("YandexART prompt length: %s", len(prompt))
            image_bytes = await self.art.generate_image(prompt)
        except Exception:
            log.exception("Изображение не сгенерировано; публикация продолжится без него")
        return title, body, image_bytes

    async def _publish_destinations(
        self,
        publication_id: int,
        title: str,
        body: str,
        image_bytes: bytes | None,
        image_path: str | None,
    ) -> dict[str, Any]:
        result = {
            "publication_id": publication_id,
            "telegram": "pending",
            "dzen": "pending",
        }

        try:
            message_id = None
            if image_bytes:
                try:
                    message_id = await send_rich_article(
                        self.bot,
                        self.cfg.telegram_channel_id,
                        title,
                        body,
                        image_bytes,
                    )
                except Exception:
                    log.exception("Rich Message не отправился, использую fallback")
                    photo = BufferedInputFile(image_bytes, filename="article.jpg")
                    photo_msg = await self.bot.send_photo(
                        chat_id=self.cfg.telegram_channel_id,
                        photo=photo,
                    )
                    message_id = str(photo_msg.message_id)
                    await send_text_chunks(
                        self.bot,
                        self.cfg.telegram_channel_id,
                        title,
                        body,
                    )
            else:
                message_id = await send_text_chunks(
                    self.bot,
                    self.cfg.telegram_channel_id,
                    title,
                    body,
                )

            await db.set_telegram_result(
                publication_id,
                "published",
                message_id=message_id,
            )
            result["telegram"] = "published"
        except Exception as exc:
            log.exception("Ошибка публикации в Telegram")
            await db.set_telegram_result(
                publication_id,
                "error",
                error=str(exc)[:1000],
            )
            result["telegram"] = "error"
            result["telegram_error"] = str(exc)

        if self.dzen is None:
            await db.set_dzen_result(
                publication_id,
                "skipped",
                error="DZEN_ENABLED=false",
            )
            result["dzen"] = "skipped"
        else:
            try:
                dzen_url = await asyncio.to_thread(
                    self.dzen.publish,
                    title=plain_text(title),
                    body=plain_text(body),
                    image_path=image_path,
                )
                await db.set_dzen_result(
                    publication_id,
                    "published",
                    url=dzen_url,
                )
                result["dzen"] = "published"
                result["dzen_url"] = dzen_url
            except Exception as exc:
                log.exception("Ошибка публикации в Дзен")
                await db.set_dzen_result(
                    publication_id,
                    "error",
                    error=str(exc)[:1000],
                )
                result["dzen"] = "error"
                result["dzen_error"] = str(exc)

        return result

    async def publish_random_topic(self, trigger: str = "auto") -> dict[str, Any]:
        async with self.lock:
            topic = await db.reserve_random_topic()
            if topic is None:
                return {"status": "no_topics"}

            topic_id = int(topic["id"])
            topic_title = topic["title"]

            try:
                title, body, image_bytes = await self._generate(topic_title)
            except Exception as exc:
                await db.release_topic(topic_id)
                log.exception("Ошибка генерации статьи")
                return {
                    "status": "generation_error",
                    "topic": topic_title,
                    "error": str(exc),
                }

            image_path = None
            if image_bytes:
                target = self.image_dir / f"topic_{topic_id}_{publication_safe_stamp()}.jpg"
                target.write_bytes(image_bytes)
                image_path = str(target)

            await db.mark_topic_used(topic_id)

            publication_id = await db.create_publication(
                topic_id=topic_id,
                topic_title=topic_title,
                article_title=title,
                article_body=body,
                image_path=image_path,
                trigger_type=trigger,
            )

            destinations = await self._publish_destinations(
                publication_id,
                title,
                body,
                image_bytes,
                image_path,
            )
            return {
                "status": "ok",
                "topic": topic_title,
                "article_title": title,
                **destinations,
            }

    async def publish_manual_topic(self, topic_title: str) -> dict[str, Any]:
        async with self.lock:
            topic_title = " ".join(topic_title.split())
            if not topic_title:
                return {"status": "generation_error", "error": "Пустая тема"}

            try:
                title, body, image_bytes = await self._generate(topic_title)
            except Exception as exc:
                log.exception("Ошибка генерации срочной статьи")
                return {
                    "status": "generation_error",
                    "topic": topic_title,
                    "error": str(exc),
                }

            topic_id = await db.add_manual_used_topic(topic_title)

            image_path = None
            if image_bytes:
                target = self.image_dir / f"manual_{topic_id}_{publication_safe_stamp()}.jpg"
                target.write_bytes(image_bytes)
                image_path = str(target)

            publication_id = await db.create_publication(
                topic_id=topic_id,
                topic_title=topic_title,
                article_title=title,
                article_body=body,
                image_path=image_path,
                trigger_type="urgent_manual",
            )

            destinations = await self._publish_destinations(
                publication_id,
                title,
                body,
                image_bytes,
                image_path,
            )
            return {
                "status": "ok",
                "topic": topic_title,
                "article_title": title,
                **destinations,
            }

    async def retry_dzen_errors(self) -> dict[str, int]:
        if self.dzen is None:
            return {"success": 0, "failed": 0, "skipped": 1}

        rows = await db.dzen_errors(limit=20)
        success = failed = 0

        async with self.lock:
            for row in rows:
                try:
                    url = await asyncio.to_thread(
                        self.dzen.publish,
                        title=plain_text(row["article_title"]),
                        body=plain_text(row["article_body"]),
                        image_path=row["image_path"],
                    )
                    await db.set_dzen_result(int(row["id"]), "published", url=url)
                    success += 1
                except Exception as exc:
                    await db.set_dzen_result(
                        int(row["id"]), "error", error=str(exc)[:1000]
                    )
                    failed += 1

        return {"success": success, "failed": failed, "skipped": 0}

def publication_safe_stamp() -> str:
    import datetime as _dt
    return _dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
