import aiosqlite

_DB_PATH: str = "bot.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    subtopic TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


async def init_db(path: str) -> None:
    global _DB_PATH
    _DB_PATH = path
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(SCHEMA)
        await db.commit()


async def add_topics(user_id: int, titles: list[str]) -> None:
    """titles — список строк, каждая строка = отдельная тема."""
    clean = [t.strip() for t in titles if t.strip()]
    if not clean:
        return
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.executemany(
            "INSERT INTO topics (user_id, title) VALUES (?, ?)",
            [(user_id, t) for t in clean],
        )
        await db.commit()


async def get_topics(user_id: int) -> list[aiosqlite.Row]:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT * FROM topics WHERE user_id = ? ORDER BY id", (user_id,)
        )
        return await cur.fetchall()


async def get_topic(topic_id: int) -> aiosqlite.Row | None:
    async with aiosqlite.connect(_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM topics WHERE id = ?", (topic_id,))
        return await cur.fetchone()


async def delete_topic(topic_id: int) -> None:
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute("DELETE FROM topics WHERE id = ?", (topic_id,))
        await db.commit()


async def update_topic_title(topic_id: int, title: str) -> None:
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute("UPDATE topics SET title = ? WHERE id = ?", (title, topic_id))
        await db.commit()


async def set_subtopic(topic_id: int, subtopic: str | None) -> None:
    async with aiosqlite.connect(_DB_PATH) as db:
        await db.execute(
            "UPDATE topics SET subtopic = ? WHERE id = ?", (subtopic, topic_id)
        )
        await db.commit()
