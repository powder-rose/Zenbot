from __future__ import annotations

import html
import re
from pathlib import Path
from playwright.sync_api import Locator, Page, sync_playwright

class DzenPublishError(RuntimeError):
    pass

def _plain_text(value: str) -> str:
    value = re.sub(r"</?(?:b|i)>", "", value, flags=re.I)
    value = re.sub(r"<[^>]+>", "", value)
    return html.unescape(value).strip()

class DzenPublisher:
    """
    Публикация через сохранённую браузерную сессию Playwright.
    Если интерфейс Дзена изменится, селекторы можно переопределить через .env.
    """
    def __init__(
        self, *, editor_url: str, profile_dir: Path, headless: bool = True,
        new_article_selector: str | None = None,
        title_selector: str | None = None,
        body_selector: str | None = None,
        publish_selector: str | None = None,
    ):
        self.editor_url = editor_url
        self.profile_dir = profile_dir
        self.headless = headless
        self.new_article_selector = new_article_selector
        self.title_selector = title_selector
        self.body_selector = body_selector
        self.publish_selector = publish_selector

    @staticmethod
    def _first_visible(page: Page, selectors: list[str]) -> Locator | None:
        for selector in selectors:
            if not selector or selector == "__never__":
                continue
            try:
                loc = page.locator(selector).first
                if loc.count() and loc.is_visible(timeout=1200):
                    return loc
            except Exception:
                continue
        return None

    @staticmethod
    def _click_by_text(page: Page, names: list[str]) -> bool:
        for name in names:
            try:
                loc = page.get_by_role("button", name=re.compile(name, re.I)).first
                if loc.count() and loc.is_visible(timeout=1500):
                    loc.click()
                    return True
            except Exception:
                pass
            try:
                loc = page.get_by_text(re.compile(name, re.I), exact=False).first
                if loc.count() and loc.is_visible(timeout=1500):
                    loc.click()
                    return True
            except Exception:
                pass
        return False

    def _open_article_editor(self, page: Page) -> None:
        page.goto(self.editor_url, wait_until="domcontentloaded", timeout=90000)
        page.wait_for_timeout(2500)

        if self._first_visible(page, [
            self.title_selector or "__never__",
            "textarea[placeholder*='Заголов']",
            "input[placeholder*='Заголов']",
        ]):
            return

        if self.new_article_selector:
            page.locator(self.new_article_selector).first.click(timeout=10000)
        elif not self._click_by_text(
            page, [r"Написать", r"Создать публикацию", r"Новая публикация", r"Статья"]
        ):
            raise DzenPublishError(
                "Не нашёл кнопку создания статьи. Укажите DZEN_NEW_ARTICLE_SELECTOR в .env."
            )

        page.wait_for_timeout(2000)
        self._click_by_text(page, [r"Статья"])
        page.wait_for_timeout(1500)

    def _fill_title(self, page: Page, title: str) -> Locator:
        loc = self._first_visible(page, [
            self.title_selector or "__never__",
            "textarea[placeholder*='Заголов']",
            "input[placeholder*='Заголов']",
            "[contenteditable='true'][data-placeholder*='Заголов']",
            "[contenteditable='true'][aria-label*='Заголов']",
        ])
        if loc is None:
            raise DzenPublishError(
                "Не нашёл поле заголовка. Укажите DZEN_TITLE_SELECTOR в .env."
            )
        try:
            loc.fill(title)
        except Exception:
            loc.click()
            page.keyboard.press("Control+A")
            page.keyboard.insert_text(title)
        return loc

    def _fill_body(self, page: Page, title_loc: Locator, body: str) -> None:
        loc = self._first_visible(page, [
            self.body_selector or "__never__",
            "[contenteditable='true'][data-placeholder*='текст']",
            "[contenteditable='true'][data-placeholder*='Текст']",
            "[contenteditable='true'][aria-label*='текст']",
            "[contenteditable='true'][aria-label*='Текст']",
        ])

        if loc is None:
            editables = page.locator("[contenteditable='true']")
            count = editables.count()
            visible = []
            for i in range(count):
                candidate = editables.nth(i)
                try:
                    if candidate.is_visible(timeout=500):
                        visible.append(candidate)
                except Exception:
                    continue
            if len(visible) >= 2:
                loc = visible[-1]

        if loc is None:
            raise DzenPublishError(
                "Не нашёл поле текста. Укажите DZEN_BODY_SELECTOR в .env."
            )

        plain = _plain_text(body)
        try:
            loc.fill(plain)
        except Exception:
            loc.click()
            page.keyboard.insert_text(plain)

    def _try_upload_image(self, page: Page, image_path: Path | None) -> None:
        if not image_path or not image_path.exists():
            return
        try:
            inputs = page.locator("input[type='file']")
            if inputs.count():
                inputs.first.set_input_files(str(image_path))
                page.wait_for_timeout(2000)
                return
        except Exception:
            pass

        for pattern in [r"Изображение", r"Фото", r"Обложка", r"Картин"]:
            try:
                button = page.get_by_text(re.compile(pattern, re.I), exact=False).first
                if button.count() and button.is_visible(timeout=700):
                    with page.expect_file_chooser(timeout=3000) as fc:
                        button.click()
                    fc.value.set_files(str(image_path))
                    page.wait_for_timeout(2000)
                    return
            except Exception:
                continue

    def _publish(self, page: Page) -> None:
        if self.publish_selector:
            page.locator(self.publish_selector).first.click(timeout=15000)
        elif not self._click_by_text(page, [r"Опубликовать", r"Публиковать"]):
            raise DzenPublishError(
                "Не нашёл кнопку публикации. Укажите DZEN_PUBLISH_SELECTOR в .env."
            )
        page.wait_for_timeout(2500)
        self._click_by_text(page, [r"Опубликовать", r"Подтвердить"])
        page.wait_for_timeout(3500)

    def publish(self, *, title: str, body: str, image_path: str | None = None) -> str:
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        image = Path(image_path) if image_path else None

        with sync_playwright() as p:
            context = p.chromium.launch_persistent_context(
                user_data_dir=str(self.profile_dir),
                headless=self.headless,
                viewport={"width": 1440, "height": 1000},
                args=["--disable-blink-features=AutomationControlled"],
            )
            try:
                page = context.pages[0] if context.pages else context.new_page()
                self._open_article_editor(page)
                title_loc = self._fill_title(page, title)
                self._fill_body(page, title_loc, body)
                self._try_upload_image(page, image)
                self._publish(page)
                if "dzen.ru" not in page.url:
                    raise DzenPublishError(f"Неожиданный URL после публикации: {page.url}")
                return page.url
            finally:
                context.close()
