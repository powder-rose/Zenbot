import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    bot_token: str
    yc_folder_id: str
    yc_api_key: str | None
    yc_sa_key_file: str | None
    db_path: str


def load_config() -> Config:
    return Config(
        bot_token=os.environ["BOT_TOKEN"],
        yc_folder_id=os.environ["YC_FOLDER_ID"],
        yc_api_key=os.environ.get("YC_API_KEY") or None,
        yc_sa_key_file=os.environ.get("YC_SA_KEY_FILE") or None,
        db_path=os.environ.get("DB_PATH", "bot.db"),
    )
