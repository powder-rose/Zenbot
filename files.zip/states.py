from aiogram.fsm.state import State, StatesGroup


class TopicStates(StatesGroup):
    waiting_for_topics = State()       # добавление тем (многострочный текст)
    waiting_for_new_title = State()    # редактирование названия темы
    waiting_for_subtopic = State()     # задание подтемы
